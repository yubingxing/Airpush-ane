
Welcome to the Airpush SDK for Android !

Included in this distribution is everything you need to integrate Airpush Push Notification ads into 
your Android applications. Get started by reading the Airpush SDK installation instruction guide at http://beta.airpush.com/r/sdk_download.php?download=2.
 
An app code project "Airtest" is included to demonstrate ad integration. We highly encourage our publishers to use "test mode" of sdk post installation to verify that ads are received correctly before the app is published on Android Market.In case, if you face any issues integrating SDK with your app please feel free to drop an email to publishersupport@airpush.com and our support team will get them resolved asap. 


